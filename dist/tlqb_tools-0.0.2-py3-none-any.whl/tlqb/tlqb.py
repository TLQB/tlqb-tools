def sum_func(a,b):
	return a+b



