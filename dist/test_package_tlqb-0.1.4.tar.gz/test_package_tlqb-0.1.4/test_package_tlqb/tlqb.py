def test(a,b):
	return a+b  
# import numpy as np
# from matplotlib import pyplot as plt
# from mpl_toolkits.mplot3d import Axes3D

# x = np.arange(0, 2*np.pi, 0.1)
# y = np.arange(0, 5, 0.1)

# X, Y = np.meshgrid(x, y)
# z = np.sin(X)*Y

# fig = plt.figure()
# ax = Axes3D(fig)
# ax.plot_surface(X, Y, z)

# # x = np.arange(-10, 10, 0.05)
# # y = x**2 + 5*np.sin(x)
# # plt.plot(X, Y, z)

# plt.xlabel("Truc x")
# plt.ylabel("Truc y")
# plt.title('Toan cao cap')

# plt.show() 